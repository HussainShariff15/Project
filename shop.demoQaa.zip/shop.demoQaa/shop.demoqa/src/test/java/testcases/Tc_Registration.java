package testcases;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Registration;

public class Tc_Registration  {
	
	static WebDriver driver;
	
	Registration object=new Registration(driver);

	@Given("^launch browser and fill details$")
	public void launch_browser_and_fill_details() throws Throwable {
	   object.url();
		}

	@When("^enter the username and password$")
	public void enter_the_username_and_password() throws Throwable {
	   object.registration();
	}



	@Then("^close the browser$")
	public void close_the_browser() throws Throwable {
	    object.signin();
	  
	}

	
	
	
			}
	
	
	
	

