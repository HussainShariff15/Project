package testcases;

import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Homepage;

public class Tc_homepage{
	/*public Tc_homepage(WebDriver driver) {
		super(driver);
	
	}*/
	
	
	static WebDriver driver;
	Homepage hm=new Homepage(driver);
	
	//M1 ob=new M1(driver);
	//ExtentTest test = report.startTest("logInTest");
	
	@Given("^click home$")
	public void homebuttonclicking() throws InterruptedException
	{
		hm.clickHome();
		//test.log(logStatus, details);
	}
	
	@When("^selecting an item$")
	public void itemselection() throws InterruptedException
	{
		
		hm.item();
	}
	@Then("^open cart and place order$")
    public void ordering() throws InterruptedException
    {
		hm.ViewCart();
    }
}
