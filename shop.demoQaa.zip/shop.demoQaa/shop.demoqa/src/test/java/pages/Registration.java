package pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.excelUtility.excelReadWrite;
import com.google.common.io.Files;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.tools.sjavac.Log;


public class Registration {
	
	Actions action;
	String excelPath = "E:\\WorkSpaceEluru\\shop.demoqa\\src\\test\\resources\\com\\testdata\\details.xlsx";	
	
	public int iterator;
	int totalRows;
	int totalColumns;
	
	
   static int j = 1;
	static WebDriver driver;
	
static Logger logger=LogManager.getLogger(Registration.class);



	public Registration(WebDriver driver) 
	{
		
	     this.driver=driver;	
	}

	public void url() throws IOException 
	{
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	driver.get("https://shop.demoqa.com/my-account/");
	System.out.println(driver.getTitle());
	takeSnap();
	}
	
	public void registration() throws IOException
	{
		

	excelReadWrite excel = new excelReadWrite(excelPath);
		totalRows = excel.getTotalRows("Sheet1");
		totalColumns = excel.getTotalcolumns("Sheet1");
	driver.findElement(By.name("username")).sendKeys(excel.readExcelData("Sheet1", 0, 0));	
	takeSnap();
	driver.findElement(By.name("email")).sendKeys(excel.readExcelData("Sheet1", 0, 1));
	driver.findElement(By.name("password")).sendKeys(excel.readExcelData("Sheet1", 0, 2));
	driver.findElement(By.xpath("//*[@id=\"customer_login\"]/div[2]/form/p[4]/button")).click();
	takeSnap();
	driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys(excel.readExcelData("Sheet1", 0, 0));
	driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(excel.readExcelData("Sheet1", 0, 2));
	takeSnap();
	ExtentReports extent;
	ExtentTest logger;
	extent=new ExtentReports("E:\\WorkSpaceEluru\\shop.demoqa\\src\\test\\resources\\extentReport2.html", true);
	logger=extent.startTest("test1");
	logger.log(LogStatus.PASS,"Registered with userdetails from excel sheet");
	
	extent.flush();
	extent.endTest(logger);
	extent.close();
	
	
	}
	

	public void signin() throws IOException
	{
		driver.findElement(By.xpath("//*[@id=\"customer_login\"]/div[1]/form/p[3]/button")).click();	
		takeSnap();
	
		logger.info("logged into the application");
	driver.quit();
	}
	
	

	public static void takeSnap() throws IOException
	{
		File scrFile;
		scrFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		Files.copy(scrFile,new File("E:\\WorkSpaceEluru\\shop.demoqa\\screenshots"+j+".jpeg"));
		j++;
	}
	
	
	
	}

