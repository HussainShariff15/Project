package pages;

import java.io.File;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.common.io.Files;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Logoutpage {

	static WebDriver driver;

	public Logoutpage(WebDriver driver)
	{
		this.driver=driver;
	}
	static Logger log=LogManager.getLogger(Logoutpage.class);
	public void clickmyaccount()
	
	{
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	WebDriver driver=new ChromeDriver();
		driver.get("https://shop.demoqa.com/checkout/order-received/4295/?key=wc_order_jiQ3X1CXjOeGM");
		driver.findElement(By.xpath("/html/body/p/a")).click();
	
		driver.findElement(By.xpath("//*[@id=\"noo-site\"]/header/div[1]/div/ul[2]/li[2]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("Hussain789"); 
		 driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("hussain123@");
		 driver.findElement(By.xpath("//*[@id=\"customer_login\"]/div[1]/form/p[3]/button")).click();
		 driver.findElement(By.xpath("//*[@id=\"post-8\"]/div/div/nav/ul/li[6]/a")).click();
		 
		 log.info("logget out from the account");
		 
		 
		 ExtentReports extent;
			ExtentTest logger;
			extent=new ExtentReports("E:\\WorkSpaceEluru\\shop.demoqa\\src\\test\\resources\\extentReport3.html", true);
			logger=extent.startTest("test1");
			logger.log(LogStatus.PASS,"logged out from the account");
			
			extent.flush();
			extent.endTest(logger);
			extent.close();
		 
	}
	
	public void clicklogout()
	{
		System.out.println("click logout");
	}
	
	public void completemsg()
	{
		System.out.println("logged out");
	}
	
	
	
}
