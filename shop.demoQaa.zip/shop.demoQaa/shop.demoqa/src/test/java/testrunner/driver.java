package testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="E:\\WorkSpaceEluru\\shop.demoqa\\src\\main\\resources\\features\\Testcase3.feature",

glue= {"testcases"})
public class driver {

}
